package ohgarmin;

public class newProg {

}
