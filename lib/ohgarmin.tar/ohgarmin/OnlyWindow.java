package ohgarmin;

public class OnlyWindow {
	boolean flag;
	
	OnlyWindow(){
		this.flag = false;
	}
	
	public void setFlag(boolean flag){
		this.flag = flag;
	}
	
	public boolean getFlag(){
		return this.flag;
	}
}
